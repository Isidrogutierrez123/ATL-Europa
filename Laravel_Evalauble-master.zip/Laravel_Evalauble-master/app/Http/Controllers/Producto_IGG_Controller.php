<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Producto_IGG;

class Producto_IGG_Controller extends Controller
{
    // Mostrar la lista de productos
    public function index()
    {
        $productos = Producto_IGG::all();
        return view('productos.index', compact('productos'));
    }

    // Mostrar detalle de un producto
    public function show($id)
    {
        $producto = Producto_IGG::findOrFail($id);
        return view('productos.show', compact('producto'));
    }
}

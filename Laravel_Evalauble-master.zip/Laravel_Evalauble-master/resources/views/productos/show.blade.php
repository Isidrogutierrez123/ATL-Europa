@extends('layouts.app')

@section('content')
<h2>Detalle del Producto</h2>
<ul class="list-group">
    <li class="list-group-item"><strong>Nombre:</strong> {{ $producto->nombre }}</li>
    <li class="list-group-item"><strong>Descripción:</strong> {{ $producto->descripcion }}</li>
    <li class="list-group-item"><strong>Precio:</strong> {{ $producto->precio }} €</li>
    <li class="list-group-item"><strong>Stock:</strong> {{ $producto->stock }}</li>
</ul>
<a href="{{ url('/productos') }}" class="btn btn-secondary mt-3">Volver a la lista</a>
@endsection

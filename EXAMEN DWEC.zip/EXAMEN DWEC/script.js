
let contadorUsuarios = 0;                 
const mensajeBienvenida = "Usuarios generados:"; 
let generacionActiva = true;              
const dominios = ["gmail.com", "yahoo.com", "outlook.com"]; 
const contenedor = document.getElementById("contenedor-tarjetas"); 


class Usuario {
  constructor(nombre, edad, email, activo) {
    this.nombre = nombre;
    this.edad = edad;
    this.email = email;
    this.activo = activo;
    this.fechaCreacion = new Date(); 
  }

  // info
  presentar() {
    return `
      <h2>${this.nombre}</h2>
      <p><strong>Edad:</strong> ${this.edad} años</p>
      <p><strong>Email:</strong> ${this.email}</p>
      <p><strong>Activo:</strong> ${this.activo ? "Sí" : "No"}</p>
      <p><strong>Fecha de registro:</strong> ${this.fechaCreacion.toLocaleDateString()}</p>
    `;
  }
}


function generarUsuarios() {
 
  contenedor.innerHTML = "";

  
  const numUsuarios = Math.floor(Math.random() * 5) + 3; 
  const listaUsuarios = []; // array de objetos Usuario

  // Bucle for 
  for (let i = 0; i < numUsuarios; i++) {
    const nombre = "Usuario" + (i + 1);
    const edad = Math.floor(Math.random() * 50) + 18; 
    const dominio = dominios[Math.floor(Math.random() * dominios.length)];
    const email = nombre.toLowerCase() + "@" + dominio;
    const activo = Math.random() > 0.5; 


    const usuario = new Usuario(nombre, edad, email, activo);
    listaUsuarios.push(usuario);
  }


  // Mostrar usuarios en tarjetas

  listaUsuarios.forEach((usuario) => {
    const tarjeta = document.createElement("div");
    tarjeta.classList.add("tarjeta");

    if (!usuario.activo) {
      tarjeta.style.opacity = "0.6"; 
    }

    tarjeta.innerHTML = usuario.presentar();
    contenedor.appendChild(tarjeta);
  });


  contadorUsuarios += numUsuarios; 
  console.log('${mensajeBienvenida} ${contadorUsuarios}');


  switch (true) {
    case numUsuarios < 4:
      console.log("Se generaron pocos usuarios.");
      break;
    case numUsuarios < 6:
      console.log("Cantidad media de usuarios.");
      break;
    default:
      console.log("¡Se generó un gran número de usuarios!");
  }
}

document.getElementById("generar-btn").addEventListener("click", () => {
  if (generacionActiva) {
    generarUsuarios();
  } else {
    console.warn("La generación de usuarios está desactivada.");
  }
});
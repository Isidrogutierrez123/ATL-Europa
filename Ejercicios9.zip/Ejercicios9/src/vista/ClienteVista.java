package vista;

import Modelo.Cliente;

import java.util.List;
import java.util.Scanner;

public class ClienteVista {
    private Scanner sc = new Scanner(System.in);

    public void mostrarMenu() {
        System.out.println("Gestión de Clientes");
        System.out.println("1. Crear cliente");
        System.out.println("2. Listar clientes");
        System.out.println("3. Modificar cliente");
        System.out.println("4. Eliminar cliente");
        System.out.println("0. Volver al menú principal");
        System.out.print("Opción: ");
    }

    public Cliente pedirDatosCliente() {
        System.out.print("Nombre del cliente: ");
        String nombre = sc.nextLine();
        System.out.print("Email del cliente: ");
        String email = sc.nextLine();
        System.out.print("Teléfono del cliente: ");
        String telefono = sc.nextLine();

        return new Cliente(nombre, email, telefono);
    }

    public void mostrarClientes(List<Cliente> clientes) {
        if (clientes.isEmpty()) {
            System.out.println("No hay clientes registrados.");
        } else {
            for (Cliente cliente : clientes) {
                System.out.println("ID: " + cliente.getId() + " | Nombre: " + cliente.getNombre() +
                        " | Email: " + cliente.getEmail() + " | Teléfono: " + cliente.getTelefono());
            }
        }
    }
}

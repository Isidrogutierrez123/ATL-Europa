<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AE_IGG Productos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <header class="bg-dark text-white p-3 mb-4">
        <div class="container">
            <h1>AE_IGG Productos</h1>
        </div>
    </header>

    <div class="container">
        @yield('content')
    </div>

    <footer class="bg-light text-center text-muted p-3 mt-4">
        &copy; 2025 AE_IGG - Todos los derechos reservados
    </footer>
</body>
</html>

﻿using System;

class Cliente
{
    public string Nombre { get; set; }
    public int Edad { get; set; }

    public decimal ObtenerDescuentoPorEdad()
    {
        if (Edad >= 0 && Edad <= 10) return 0.5m;
        if (Edad >= 11 && Edad <= 18) return 0.3m;
        if (Edad >= 19 && Edad <= 26) return 0.1m;
        if (Edad >= 27 && Edad <= 64) return 0.0m;
        if (Edad >= 65) return 0.5m;
        return 0.0m;
    }
}

class Obra
{
    public string Titulo { get; set; }
    public int Duracion { get; set; }
    public decimal Precio { get; set; }
}

class Teatro
{
    public string Nombre { get; set; }
    public string Domicilio { get; set; }
    public Obra ObraActual { get; set; }
    public Cliente[,] Butacas { get; set; }

    public Teatro()
    {
        Butacas = new Cliente[10, 5];
    }

    public bool Vender(int fila, int columna, Cliente c)
    {
        if (fila < 0 || fila >= 10 || columna < 0 || columna >= 5) return false;
        if (Butacas[fila, columna] == null)
        {
            Butacas[fila, columna] = c;
            return true;
        }
        return false;
    }

    public bool Cancelar(int fila, int columna)
    {
        if (fila < 0 || fila >= 10 || columna < 0 || columna >= 5) return false;
        if (Butacas[fila, columna] != null)
        {
            Butacas[fila, columna] = null;
            return true;
        }
        return false;
    }

    public string ListarTodas()
    {
        string resultado = "";
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                resultado += $"Fila {i+1}, Butaca {j+1}: " +
                             (Butacas[i, j] == null ? "Libre" : "Ocupada") + "\n";
            }
        }
        return resultado;
    }

    public string ListarLibres()
    {
        string resultado = "";
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                if (Butacas[i, j] == null)
                    resultado += $"Fila {i+1}, Butaca {j+1}\n";
            }
        }
        return resultado;
    }

    public string ListarOcupadas()
    {
        string resultado = "";
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                if (Butacas[i, j] != null)
                {
                    Cliente c = Butacas[i, j];
                    resultado += $"Fila {i+1}, Butaca {j+1}: {c.Nombre}, Edad {c.Edad}\n";
                }
            }
        }
        return resultado;
    }

    public decimal CalcularRecaudacion()
    {
        decimal total = 0;
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                if (Butacas[i, j] != null)
                {
                    Cliente c = Butacas[i, j];
                    decimal descuento = c.ObtenerDescuentoPorEdad();
                    total += ObraActual.Precio * (1 - descuento);
                }
            }
        }
        return total;
    }
}

class Program
{
    static void Main()
    {
        Teatro teatro = new Teatro
        {
            Nombre = "Teatro del Barrio",
            Domicilio = "Calle Mayor 123",
            ObraActual = new Obra { Titulo = "La Gran Obra", Duracion = 120, Precio = 20m }
        };

        int opcion;
        do
        {
            Console.WriteLine("\n--- Menú ---");
            Console.WriteLine("1. Vender una entrada");
            Console.WriteLine("2. Cancelar una entrada");
            Console.WriteLine("3. Listado de localidades (completo)");
            Console.WriteLine("4. Listado de localidades libres");
            Console.WriteLine("5. Listado de localidades ocupadas");
            Console.WriteLine("6. Calcular recaudación");
            Console.WriteLine("7. Terminar programa");
            Console.Write("Elige opción: ");
            opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.Write("Fila (1-10): ");
                    int f = int.Parse(Console.ReadLine()) - 1;
                    Console.Write("Butaca (1-5): ");
                    int b = int.Parse(Console.ReadLine()) - 1;
                    Console.Write("Nombre cliente: ");
                    string nombre = Console.ReadLine();
                    Console.Write("Edad cliente: ");
                    int edad = int.Parse(Console.ReadLine());
                    Cliente cli = new Cliente { Nombre = nombre, Edad = edad };
                    if (teatro.Vender(f, b, cli))
                        Console.WriteLine("Entrada vendida.");
                    else
                        Console.WriteLine("No se pudo vender (ocupada o inválida).");
                    break;

                case 2:
                    Console.Write("Fila (1-10): ");
                    f = int.Parse(Console.ReadLine()) - 1;
                    Console.Write("Butaca (1-5): ");
                    b = int.Parse(Console.ReadLine()) - 1;
                    if (teatro.Cancelar(f, b))
                        Console.WriteLine("Entrada cancelada.");
                    else
                        Console.WriteLine("No se pudo cancelar (libre o inválida).");
                    break;

                case 3:
                    Console.WriteLine(teatro.ListarTodas());
                    break;

                case 4:
                    Console.WriteLine(teatro.ListarLibres());
                    break;

                case 5:
                    Console.WriteLine(teatro.ListarOcupadas());
                    break;

                case 6:
                    Console.WriteLine($"Recaudación total: {teatro.CalcularRecaudacion()} €");
                    break;
            }

        } while (opcion != 7);
    }
}

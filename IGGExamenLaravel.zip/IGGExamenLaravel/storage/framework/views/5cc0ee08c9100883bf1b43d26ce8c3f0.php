<!DOCTYPE html>
<html>
<head>
    <title>Detalle de Categoría</title>
</head>
<body>
    <h1><?php echo e($categoria->nombre); ?></h1>
    <a href="<?php echo e(route('categorias.index')); ?>">Volver</a>
</body<?php /**PATH C:\xampp\htdocs\laravel\Examen1-IGG\IGGExamenLaravel\resources\views/categorias/show.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>Detalle de Categoría</title>
</head>
<body>
    <h1>{{ $categoria->nombre }}</h1>
    <a href="{{ route('categorias.index') }}">Volver</a>
</body
package Modelo;

import java.sql.*;
import java.util.ArrayList;

public class ClienteDAO {

    public void insertarCliente(Cliente c) {
        Connection con = ConexionBD.conectar();
        if (con != null) {
            try {
                String sql = "INSERT INTO Clientes (nombre, email, telefono) VALUES (?, ?, ?)";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, c.getNombre());
                ps.setString(2, c.getEmail());
                ps.setString(3, c.getTelefono());
                ps.executeUpdate();
                ps.close();
                con.close();
            } catch (SQLException e) {
                System.out.println("Error al insertar cliente.");
            }
        }
    }

    public ArrayList<Cliente> obtenerClientes() {
        ArrayList<Cliente> lista = new ArrayList<>();
        Connection con = ConexionBD.conectar();
        if (con != null) {
            try {
                String sql = "SELECT * FROM Clientes";
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(sql);
                while (rs.next()) {
                    Cliente c = new Cliente(
                        rs.getInt("id_cliente"),
                        rs.getString("nombre"),
                        rs.getString("email"),
                        rs.getString("telefono")
                    );
                    lista.add(c);
                }
                rs.close();
                st.close();
                con.close();
            } catch (SQLException e) {
                System.out.println("Error al obtener clientes.");
            }
        }
        return lista;
    }

    public void actualizarCliente(Cliente c) {
        Connection con = ConexionBD.conectar();
        if (con != null) {
            try {
                String sql = "UPDATE Clientes SET nombre=?, email=?, telefono=? WHERE id_cliente=?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, c.getNombre());
                ps.setString(2, c.getEmail());
                ps.setString(3, c.getTelefono());
                ps.setInt(4, c.getId());
                ps.executeUpdate();
                ps.close();
                con.close();
            } catch (SQLException e) {
                System.out.println("Error al actualizar cliente.");
            }
        }
    }

    public void eliminarCliente(int id) {
        Connection con = ConexionBD.conectar();
        if (con != null) {
            try {
                String sql = "DELETE FROM Clientes WHERE id_cliente=?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setInt(1, id);
                ps.executeUpdate();
                ps.close();
                con.close();
            } catch (SQLException e) {
                System.out.println("Error al eliminar cliente.");
            }
        }
    }
}

<?php


use App\Http\Controllers\CategoriaController;

Route::resource('categorias', CategoriaController::class);


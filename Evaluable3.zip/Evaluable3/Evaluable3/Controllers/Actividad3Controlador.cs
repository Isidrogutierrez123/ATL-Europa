﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Evaluable3.Controllers
{
    public class Actividad3Controlador : Controller
    {
        // GET: Actividad3Controlador
        public ActionResult Index()
        {
            return View();
        }

        // GET: Actividad3Controlador/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Actividad3Controlador/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Actividad3Controlador/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Actividad3Controlador/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Actividad3Controlador/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Actividad3Controlador/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Actividad3Controlador/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}

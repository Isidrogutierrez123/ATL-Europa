package Controlador;



import Modelo.Cliente;
import Modelo.ClienteDAO;
import vista.ClienteVista;

import java.util.Scanner;
import java.util.List;

public class ClienteControlador {
    private ClienteDAO clienteDAO = new ClienteDAO();
    private ClienteVista vistaCliente = new ClienteVista();
    private Scanner sc = new Scanner(System.in);

    public void iniciar() {
        int opcion;
        do {
            vistaCliente.mostrarMenu();
            try {
                opcion = Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                opcion = -1;
            }

            switch (opcion) {
                case 1:
                    Cliente nuevo = vistaCliente.pedirDatosCliente();
                    clienteDAO.insertar(nuevo);
                    break;
                case 2:
                    List<Cliente> clientes = clienteDAO.obtenerTodos();
                    vistaCliente.mostrarClientes(clientes);
                    break;
                case 3:
                    System.out.print("ID del cliente a modificar: ");
                    int idMod = Integer.parseInt(sc.nextLine());
                    Cliente modificado = vistaCliente.pedirDatosCliente();
                    modificado.setId(idMod);
                    clienteDAO.actualizar(modificado);
                    break;
                case 4:
                    System.out.print("ID del cliente a eliminar: ");
                    int idDel = Integer.parseInt(sc.nextLine());
                    clienteDAO.eliminar(idDel);
                    break;
                case 0:
                    System.out.println("Volviendo al menú principal...");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }
}

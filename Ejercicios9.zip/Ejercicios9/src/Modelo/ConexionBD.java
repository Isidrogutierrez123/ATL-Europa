package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

public class ConexionBD {
    public static void main(String[] args) {
        // Parámetros de conexión
        String url = "jdbc:mysql://localhost:3306/ejercicio9";
        String user = "root";  // Cambia el usuario si es necesario
        String password = "curso";  // Cambia la contraseña si es necesario

        // Intentar conectar a la base de datos
        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            if (connection != null) {
                System.out.println("¡Conexión exitosa a la base de datos!");

                // Crear la consulta
                String query = "SELECT * FROM Clientes"; // Cambia "Clientes" por el nombre de una tabla válida

                // Ejecutar la consulta
                try (Statement statement = connection.createStatement();
                     ResultSet resultSet = statement.executeQuery(query)) {

                    // Mostrar los resultados
                    while (resultSet.next()) {
                        System.out.println("ID Cliente: " + resultSet.getInt("id_cliente"));
                        System.out.println("Nombre: " + resultSet.getString("nombre"));
                        System.out.println("Email: " + resultSet.getString("email"));
                        System.out.println("Teléfono: " + resultSet.getString("telefono"));
                        System.out.println("----------------------------");
                    }
                }
            } else {
                System.out.println("No se pudo conectar a la base de datos.");
            }
        } catch (SQLException e) {
            System.out.println("Error al conectar: " + e.getMessage());
        }
    }
}

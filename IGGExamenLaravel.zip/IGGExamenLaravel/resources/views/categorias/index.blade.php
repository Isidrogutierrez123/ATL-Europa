<!DOCTYPE html>
<html>
<head>
    <title>Categorías</title>
    <style>
        table {
            border-collapse: collapse;
            width: 70%;
        }
        th, td {
            border: 1px solid #333;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #eee;
        }
        button {
            padding: 5px 10px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>Lista de Categorías</h1>

    @if($categorias->isEmpty())
        <p>No hay categorías registradas.</p>
    @else
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach($categorias as $categoria)
                    <tr>
                        <td>{{ $categoria->id }}</td>
                        <td>{{ $categoria->nombre }}</td>
                        <td>{{ $categoria->descripcion }}</td>
                        <td>
                            <a href="{{ route('categorias.show', $categoria->id) }}">
                                <button type="button">Ver detalles</button>
                            </a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif

    <h2>Añadir nueva categoría</h2>
    <form action="{{ route('categorias.store') }}" method="POST">
        @csrf
        <input type="text" name="nombre" placeholder="Nombre de categoría" required>
        <input type="text" name="descripcion" placeholder="Descripción" required>
        <button type="submit">Guardar</button>
    </form>
</body>
</html>
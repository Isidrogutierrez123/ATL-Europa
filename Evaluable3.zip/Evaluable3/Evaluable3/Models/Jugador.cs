﻿

namespace Evaluable3.Models
{

    public class Jugador
    {
        public string Nombre { get; set; }
        public int Dorsal { get; set; }
        public string Posicion { get; set; }
    }
}
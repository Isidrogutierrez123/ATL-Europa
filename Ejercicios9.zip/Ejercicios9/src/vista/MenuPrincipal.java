package vista;



import java.util.Scanner;

public class MenuPrincipal {
    private Scanner sc = new Scanner(System.in);

    public int mostrarMenu() {
        System.out.println("Menú Principal");
        System.out.println("1. Gestión de Clientes");
        System.out.println("0. Salir");
        System.out.print("Opción: ");
        return Integer.parseInt(sc.nextLine());
    }
}

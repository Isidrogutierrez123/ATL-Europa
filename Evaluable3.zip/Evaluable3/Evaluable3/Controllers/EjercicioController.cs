﻿using Microsoft.AspNetCore.Mvc;
using Evaluable3.Models; // <- namespace correcto de tu proyecto

namespace Evaluable3.Controllers
{
    public class EjercicioController : Controller
    {
        // =========================
        // EJERCICIO 1 - FORMULARIO
        // =========================

        [HttpGet]
        public IActionResult Ejercicio1()
        {
            // Muestra el formulario vacío
            return View();
        }

        [HttpPost]
        public IActionResult Ejercicio1(string equipoLocal, string equipoVisitante, int golesLocal, int golesVisitante)
        {
            // Calcula el resultado del partido
            string resultado = CalcularResultado(equipoLocal, equipoVisitante, golesLocal, golesVisitante);
            ViewBag.Resultado = resultado;
            return View();
        }

        // Función auxiliar para calcular el resultado del partido
        private string CalcularResultado(string local, string visitante, int golesLocal, int golesVisitante)
        {
            if (golesLocal > golesVisitante)
                return $"Gana {local} ({golesLocal}-{golesVisitante})";
            else if (golesLocal < golesVisitante)
                return $"Gana {visitante} ({golesLocal}-{golesVisitante})";
            else
                return $"Empate ({golesLocal}-{golesVisitante})";
        }

        // =========================
        // EJERCICIO 2 - TABLA DE JUGADORES
        // =========================

        public IActionResult Ejercicio2()
        {
            // Creamos un array de jugadores
            Jugador[] jugadores = new Jugador[]
            {
                new Jugador { Nombre="Juan", Dorsal=1, Posicion="Portero" },
                new Jugador { Nombre="Luis", Dorsal=9, Posicion="Delantero" },
                new Jugador { Nombre="Pedro", Dorsal=11, Posicion="Centrocampista" },
                new Jugador { Nombre="Miguel", Dorsal=7, Posicion="Delantero" }
            };

            // Pasamos el array a la vista
            return View(jugadores);
        }
    }
}

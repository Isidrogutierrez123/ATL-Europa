<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Producto_IGG extends Model
{
    use HasFactory;

    // Nombre de la tabla (opcional si coincide con el modelo en plural)
    protected $table = 'productos_IGG';

    // Campos que se pueden asignar masivamente
    protected $fillable = [
        'nombre',
        'descripcion',
        'precio',
        'stock',
    ];
}

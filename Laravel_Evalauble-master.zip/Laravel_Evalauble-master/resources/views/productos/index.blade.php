@extends('layouts.app')

@section('content')
<h2>Lista de Productos</h2>
<table class="table table-striped">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Stock</th>
            <th>Detalle</th>
        </tr>
    </thead>
    <tbody>
        @foreach($productos as $producto)
        <tr>
            <td>{{ $producto->nombre }}</td>
            <td>{{ $producto->precio }} €</td>
            <td>{{ $producto->stock }}</td>
            <td><a href="{{ url('/productos/'.$producto->id) }}" class="btn btn-primary btn-sm">Ver</a></td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection
